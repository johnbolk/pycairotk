**A Tkinter DrawArea wrapper class for the pycairo package.**

This package provides an alternative to the Tkinter Canvas widget for rendering and displaying graphics objects. The **DrawArea** widget is a high-level wrapper class for the **pycairo** package, which implements many of that package's graphics and text rendering capabilities. One of these is the ability to generate sub-pixel graphics resolution by using the anti-aliasing capabilities. Another is the ability to render text and graphics using full 32-bit, RGBA colors.

An important difference from either the Tkinter Canvas widget or the **pycairo** package, is that the **DrawArea** widget class was defined to operate in a standard, right-handed coordinate system. This means that the y-axis coordinate value increases from the bottom of the display to the top of the display.

In addition to the **DrawArea** widget, this package also includes a fully defined **Vector** class. This class represents a geometric vector in the xy plane, and it is an extremely useful and powerful tool for creating and manipulating graphic objects. In fact, the **DrawArea** widget was implemented using the **Vector** class.

In summary, this package adds a fully compatible **DrawArea** widget to Tkinter's set of graphical user interface widgets, thereby providing the user with a convenient tool for working with the **pycairo** package in any Tkinter window based application.

## Overview

This package provides the following class definitions **:**

* **DrawArea -** A Tkinter widget class for rendering and displaying graphics
* **BorderStyle -** A data class of the available border style options
* **Brush -** A data class of graphics rendering options
* **Font -** A data class for describing a text font
* **TextStyle -** A data class of text rendering options
* **Shape -** An enumerated class of available datapoint shapes
* **LineCap -** An enumerated class of available line endpoint options
* **LineJoin -** An enumerated class of available line junction options
* **Antialias -** An enumerated class of available rendering options
* **Size -** A named tuple class of the width and height dimensions of an object
* **Vector -** A class which represents a geometric vector in the xy plane

The **DrawArea** widget class provides the rectangular area where the graphics and text objects are rendered and displayed on the screen.

The **Antialias** and **BorderStyle** classes are used to specify the configuration and display options for the **DrawArea** widget class.

The **Brush** and **Shape** classes are used to specify the rendering options for the various **DrawArea** graphics rendering methods.

The **LineCap** and **LineJoin** classes are used to specify the line rendering options for the **Brush** class.

The **Font** and **TextStyle** classes are used to specify the rendering options for the **DrawArea** text rendering method.

The **Size** and **Vector** classes not are required for using the **DrawArea** rendering methods, but are provided as "helper" classes for the user. The **Size** class is a useful way to specify the dimensions of a graphics object, and the **Vector** class is a very useful tool for specifying and manipulating the location coordinates of graphic objects.

## Documentation

Full documentation for all the classes contained in this package, as well as usage examples, are available at the package's GitHub repository: https://github.com/johnbolk/pycairotk
